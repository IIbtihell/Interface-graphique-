from PyQt5 import QtWidgets,uic

def main3():
    app.quit()

def main2():
    call2.show()
    call2.close.clicked.connect(main3)

def main1():
    call1.show()
def main4():
    call2.show()
    



app=QtWidgets.QApplication([])
call=uic.loadUi('Welcome.ui')
call.Start.clicked.connect(main1)
call1=uic.loadUi('Shop.ui')
call1.Buy.clicked.connect(main4)
call2=uic.loadUi('untitled.ui')
call.show()
call.Start.clicked.connect(main1)
app.exec()

