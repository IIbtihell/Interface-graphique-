from PyQt5 import QtWidgets,uic

def main3():
    app.quit()

def main2():
    call2.show()
    call2.close.clicked.connect(main3)


def main():
    a=call.q1.text()
    b=call.q2.text()
    d=call.q4.text()
    t=[]
    x=call.q5.isChecked()
    if x:
        f="Masculin"
    if not x :
        f="Féminin"
    y=call.q7.isChecked()
    z=call.q8.isChecked()
    m=call.q9.isChecked()
    n=call.q10.isChecked()
    if y:
        t.append("Piscine")
    if z:
        t.append("Sport")
    if m:
        t.append("Sortie")
    if n:
        t.append("Disco")
    call1.confirm.clicked.connect(main2)
    call1.np.setText(a)
    call1.mail.setText(b)
    call1.cin.setText(d)
    call1.genre.setText(f)
    call1.option.setText(f'{t}')
    call1.show()


app=QtWidgets.QApplication([])
call=uic.loadUi('untitled.ui')
call1=uic.loadUi('valider.ui')
call2=uic.loadUi('vrai.ui')
call.show()
call.valider.clicked.connect(main)
call.out.clicked.connect(main3)
app.exec()

